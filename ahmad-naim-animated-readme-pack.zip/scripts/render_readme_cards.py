import json
import os

STATIC = os.environ.get("STATIC", "0") == "1"

BASE_STYLE = """
  <style>
    .bg { fill: #0d1117; stroke: #30363d; stroke-width: 1.2; }
    .card-bg { fill: #161b22; stroke: #30363d; stroke-width: 1.2; }
    .title { font: 700 28px -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; fill: #f0f6fc; }
    .subtitle { font: 500 14px 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; fill: #58a6ff; }
    .body { font: 400 13px -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; fill: #8b949e; }
    .card-title { font: 700 16px -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; fill: #f0f6fc; }
    .tag { font: 600 11px 'SFMono-Regular', Consolas, monospace; fill: #79c0ff; }
    .stat-num { font: 700 22px -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; fill: #f0f6fc; }
    .stat-lbl { font: 500 11px 'SFMono-Regular', Consolas, monospace; fill: #8b949e; }

    @keyframes fadeSlideUp {
      0% { opacity: 0; transform: translateY(10px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    @keyframes pulseDot {
      0%, 100% { opacity: 1; r: 4; }
      50% { opacity: 0.4; r: 6; }
    }
    @keyframes growBar {
      0% { transform: scaleY(0); }
      100% { transform: scaleY(1); }
    }
    @keyframes popIn {
      0% { opacity: 0; transform: scale(0.7); }
      100% { opacity: 1; transform: scale(1); }
    }

    .anim-1 { opacity: 0; animation: fadeSlideUp 0.6s ease-out 0.1s forwards; }
    .anim-2 { opacity: 0; animation: fadeSlideUp 0.6s ease-out 0.3s forwards; }
    .anim-3 { opacity: 0; animation: fadeSlideUp 0.6s ease-out 0.5s forwards; }
    .pulse { animation: pulseDot 2s infinite ease-in-out; }
    .bar { transform-box: fill-box; transform-origin: bottom; transform: scaleY(0); animation: growBar 0.7s cubic-bezier(0.22, 1, 0.36, 1) forwards; }

    @media (prefers-reduced-motion: reduce) {
      .anim-1, .anim-2, .anim-3, .pulse, .bar {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
"""

STATIC_OVERRIDE = """
  <style>
    .anim-1, .anim-2, .anim-3, .pulse, .bar {
      animation: none !important;
      opacity: 1 !important;
      transform: none !important;
    }
  </style>
""" if STATIC else ""


def render_hero():
    ascii_lines = [
        "    .--------.    ",
        "   /  .-==-.  \\   ",
        "  |  /      \\  |  ",
        "  | |  o  o  | |  ",
        "  | |   __   | |  ",
        "   \\  '----'  /   ",
        "   _/'------'\\_   ",
        "  /  |  AN  |  \\  ",
        " /___|______|___\\ "
    ]
    ascii_svg = []
    for i, line in enumerate(ascii_lines):
        delay = 0.15 + i * 0.06
        style = "opacity:1;" if STATIC else f"opacity:0;animation:fadeSlideUp 0.35s ease-out {delay:.2f}s forwards;"
        ascii_svg.append(
            f'<text x="695" y="{52 + i * 16}" font-family="Consolas, monospace" font-size="13" fill="#58a6ff" xml:space="preserve" style="{style}">{line}</text>'
        )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="880" height="220" viewBox="0 0 880 220" fill="none">
  <defs>
    <linearGradient id="shine" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#f0f6fc"/>
      <stop offset="45%" stop-color="#f0f6fc"/>
      <stop offset="50%" stop-color="#58a6ff"/>
      <stop offset="55%" stop-color="#f0f6fc"/>
      <stop offset="100%" stop-color="#f0f6fc"/>
      <animateTransform attributeName="gradientTransform" type="translate" from="-1 0" to="1 0" dur="4s" repeatCount="indefinite"/>
    </linearGradient>
  </defs>
  {BASE_STYLE}
  {STATIC_OVERRIDE}
  <rect x="1" y="1" width="878" height="218" rx="14" class="bg"/>
  <circle cx="38" cy="36" r="4" fill="#3fb950" class="pulse"/>
  <text x="52" y="40" class="subtitle anim-1">SOFTWARE DEVELOPER @SCHOLARIFYACADEMY • YOGYAKARTA, ID</text>
  <text x="34" y="84" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif" font-size="34" font-weight="800" fill="url(#shine)" class="anim-1">Ahmad Naim</text>
  <text x="34" y="114" class="body anim-2">Full-Stack Web Developer building clean, responsive UI &amp; structured data systems.</text>
  <text x="34" y="136" class="body anim-2">Currently shipping Scholarify Academy &amp; Sabana Adventure (Asah Dicoding Capstone).</text>

  <g class="anim-3">
    <rect x="34" y="160" width="110" height="28" rx="6" fill="#161b22" stroke="#30363d"/>
    <text x="52" y="178" class="tag">TypeScript</text>
    <rect x="154" y="160" width="90" height="28" rx="6" fill="#161b22" stroke="#30363d"/>
    <text x="176" y="178" class="tag">Next.js</text>
    <rect x="254" y="160" width="80" height="28" rx="6" fill="#161b22" stroke="#30363d"/>
    <text x="275" y="178" class="tag">React</text>
    <rect x="344" y="160" width="145" height="28" rx="6" fill="#161b22" stroke="#30363d"/>
    <text x="360" y="178" class="tag">ahmadnaim.site</text>
  </g>

  <rect x="670" y="28" width="180" height="164" rx="10" fill="#161b22" stroke="#30363d"/>
  {''.join(ascii_svg)}
</svg>"""
    with open("readme_pack/cards/hero.svg", "w", encoding="utf-8") as f:
        f.write(svg)


def render_project_card(filename, badge, title, line1, line2, stack, accent, delay):
    anim = "opacity:1;" if STATIC else f"opacity:0;animation:fadeSlideUp 0.6s ease-out {delay}s forwards;"
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="286" height="190" viewBox="0 0 286 190" fill="none">
  {BASE_STYLE}
  {STATIC_OVERRIDE}
  <g style="{anim}">
    <rect x="1" y="1" width="284" height="188" rx="12" class="card-bg"/>
    <rect x="1" y="1" width="284" height="4" rx="2" fill="{accent}"/>
    <text x="20" y="34" font-family="Consolas, monospace" font-size="11" font-weight="700" fill="{accent}">{badge}</text>
    <text x="20" y="64" class="card-title">{title}</text>
    <text x="20" y="92" class="body">{line1}</text>
    <text x="20" y="112" class="body">{line2}</text>
    <line x1="20" y1="138" x2="266" y2="138" stroke="#30363d" stroke-width="1"/>
    <text x="20" y="164" class="tag">{stack}</text>
    <text x="252" y="164" font-family="Consolas, monospace" font-size="14" fill="{accent}">↗</text>
  </g>
</svg>"""
    with open(f"readme_pack/cards/{filename}", "w", encoding="utf-8") as f:
        f.write(svg)


def render_activity(data):
    months = data["months"]
    max_val = max(m["count"] for m in months) or 1
    bars = []
    for idx, m in enumerate(months):
        x = 38 + idx * 68
        h = int((m["count"] / max_val) * 95)
        y = 165 - h
        is_best = m["count"] == max_val
        fill = "#58a6ff" if is_best else "#238636"
        delay = 0.2 + idx * 0.05
        style = "" if STATIC else f"animation-delay:{delay:.2f}s;"
        bars.append(f'<rect x="{x}" y="{y}" width="36" height="{h}" rx="5" fill="{fill}" class="bar" style="{style}"/>')
        bars.append(f'<text x="{x + 18}" y="185" text-anchor="middle" class="stat-lbl">{m["label"]}</text>')
        if is_best:
            bars.append(f'<text x="{x + 18}" y="{y - 8}" text-anchor="middle" font-family="Consolas, monospace" font-size="11" font-weight="700" fill="#58a6ff">{m["count"]}</text>')

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="880" height="215" viewBox="0 0 880 215" fill="none">
  {BASE_STYLE}
  {STATIC_OVERRIDE}
  <rect x="1" y="1" width="878" height="213" rx="14" class="bg"/>
  <text x="34" y="36" class="card-title">Monthly Engineering Activity</text>
  <text x="34" y="54" class="stat-lbl">Updated via local data/contributions.json • Highlighted peak month</text>

  <g transform="translate(620, 24)">
    <rect x="0" y="0" width="110" height="44" rx="8" fill="#161b22" stroke="#30363d"/>
    <text x="14" y="20" class="stat-lbl">STREAK</text>
    <text x="14" y="37" font-family="Segoe UI, sans-serif" font-size="15" font-weight="700" fill="#3fb950">{data["streak_days"]} days</text>

    <rect x="120" y="0" width="110" height="44" rx="8" fill="#161b22" stroke="#30363d"/>
    <text x="134" y="20" class="stat-lbl">TOTAL</text>
    <text x="134" y="37" font-family="Segoe UI, sans-serif" font-size="15" font-weight="700" fill="#58a6ff">{data["total_contributions"]}</text>
  </g>

  <line x1="34" y1="165" x2="846" y2="165" stroke="#30363d" stroke-width="1"/>
  {''.join(bars)}
</svg>"""
    with open("readme_pack/cards/activity.svg", "w", encoding="utf-8") as f:
        f.write(svg)


if __name__ == "__main__":
    with open("readme_pack/data/contributions.json", "r", encoding="utf-8") as f:
        data = json.load(f)

    render_hero()
    render_project_card(
        "scholarify.svg",
        "PRODUCTION • EDTECH",
        "Scholarify Academy",
        "Company profile & SNBT tryout",
        "platform with data analytics.",
        "Next.js • TypeScript",
        "#58a6ff",
        0.25,
    )
    render_project_card(
        "sabana.svg",
        "CAPSTONE • DICODING",
        "Sabana Adventure",
        "CRM Admin Retail Dashboard &",
        "interactive Customer Catalog.",
        "Full-Stack • CRM",
        "#3fb950",
        0.40,
    )
    render_project_card(
        "aira.svg",
        "WEB SYSTEM • CRUD",
        "Aira Dry Cleaning",
        "Self-service online booking,",
        "pricing & pickup scheduling.",
        "React • Payment Gateway",
        "#d2a8ff",
        0.55,
    )
    render_activity(data)
    print("All SVG cards generated successfully.")
