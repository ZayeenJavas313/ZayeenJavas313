<!-- Animated Hero Card -->
<div align="center">
  <img src="./cards/hero.svg" width="100%" alt="Ahmad Naim Hero Card" />
</div>

<br />

<!-- Social & Contact Links -->
<div align="center">
  <a href="https://www.ahmadnaim.site" target="_blank">
    <img src="https://img.shields.io/badge/Portfolio-0A0A0A?style=for-the-badge&logo=vercel&logoColor=white" alt="Portfolio" />
  </a>
  <a href="https://www.linkedin.com/in/ahmadznaim" target="_blank">
    <img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" />
  </a>
  <a href="https://instagram.com/ahmadznaim_" target="_blank">
    <img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white" alt="Instagram" />
  </a>
  <a href="mailto:ahmdnaim3@gmail.com">
    <img src="https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white" alt="Email" />
  </a>
</div>

<br />

<!-- Three Featured Project Tiles -->
<div align="center">
  <a href="https://scholarify.id/"><img src="./cards/scholarify.svg" width="32.5%" alt="Scholarify Academy" /></a>
  <a href="https://github.com/ZayeenJavas313"><img src="./cards/sabana.svg" width="32.5%" alt="Sabana Adventure" /></a>
  <a href="https://www.ahmadnaim.site"><img src="./cards/aira.svg" width="32.5%" alt="Aira Dry Cleaning" /></a>
</div>

<br />

<!-- Animated Activity Chart Card -->
<div align="center">
  <img src="./cards/activity.svg" width="100%" alt="Monthly Activity Chart" />
</div>

---

### 👨‍💻 About Me

Full-stack web developer focused on building maintainable, responsive, and reliable web applications—bridging intuitive user interfaces with structured application logic and real-world workflows.

- 🔭 **Current focus:** [Scholarify Academy](https://scholarify.id/) & **Sabana Adventure** *(Asah Dicoding Capstone Project)*
- 🌱 **Continuous learning:** Data Structures & Algorithms (Linked Lists, Trees, Optimization) and scalable UI architecture
- 💬 **Core expertise:** TypeScript, React, Next.js, Full-Stack Web Development, and Frontend Engineering
- 📫 **Get in touch:** [ahmdnaim3@gmail.com](mailto:ahmdnaim3@gmail.com)

---

### 🛠️ Tech Stack

<div align="center">
  <img src="https://img.shields.io/badge/TypeScript-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript" />
  <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" alt="JavaScript" />
  <img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" alt="React" />
  <img src="https://img.shields.io/badge/Next.js-000000?style=for-the-badge&logo=nextdotjs&logoColor=white" alt="Next.js" />
  <img src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white" alt="Java" />
  <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" alt="HTML5" />
  <img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" alt="CSS3" />
</div>

---

### 📊 GitHub Analytics

<div align="center">
  <a href="https://github.com/ZayeenJavas313">
    <img height="175em" src="https://github-readme-stats.vercel.app/api?username=ZayeenJavas313&show_icons=true&theme=github_dark&include_all_commits=true&count_private=true&hide_border=true" alt="Ahmad Naim's GitHub Stats" />
    <img height="175em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=ZayeenJavas313&layout=compact&langs_count=8&theme=github_dark&hide_border=true" alt="Top Languages" />
  </a>
</div>

<br />

<div align="center">
  <img src="https://streak-stats.demolab.com?user=ZayeenJavas313&theme=github_dark_blue&hide_border=true" alt="GitHub Streak" />
</div>
